local wvv = pd.Class:new():register("rwvv1")

function wvv:initialize()
  self:set_size(808, 376)
  self.inlets  = 1
  return true
end

local abs = math.abs


function wvv:postinitialize()
  self:repaint()
end

function wvv:in_1()
self:repaint()
end

function wvv:paint(g)

  local wetsigmax = pd.Table:new():sync("waveformmax")  
  local wetsigmin = pd.Table:new():sync("waveformmin")  
  local scsigmax = pd.Table:new():sync("drumsmax")  
  local scsigmin = pd.Table:new():sync("drumsmin") 

  local wp = Path(19,(wetsigmin:get(0) or 0)*172+172+16)

  for i = 1, 385 do

    local y = (wetsigmax:get(i+2) or 0)*172+172+17
    wp:line_to(i*2+19,y)
    if ((wetsigmax:get(i+2) or 0) - (wetsigmax:get(i+1) or 0)) * ((wetsigmax:get(i+3) or 0) - (wetsigmax:get(i+2) or 0)) < 0 then
    wp:line_to(i*2+20,y)
    end

  end

  for i = 385, 1, -1 do
    local y = (wetsigmin:get(i+2) or 0)*172+172+15
    wp:line_to(i*2+19,y)
    if ((wetsigmin:get(i+2) or 0) - (wetsigmin:get(i+1) or 0)) * ((wetsigmin:get(i+3) or 0) - (wetsigmin:get(i+2) or 0)) < 0 then
    wp:line_to(i*2+18,y)
    end
  end

  g:set_color(37,37,47,1)
  g:fill_path(wp)

  local validwave = 0

  for i = 1, 389 do

  if i < 389 and abs(scsigmax:get(i-1) or 0) > 0.00001 then

  validwave = validwave + 1

  elseif validwave > 0 then

  local scp = Path((i-validwave-1)*2+16,(scsigmin:get(i-validwave-1) or 0)*172+172+16)

  for e = i-validwave, i-1  do
  local y = (scsigmax:get(e-1) or 0)*172+172+17
  scp:line_to(e*2+16,y)
  if e < i-1 and ((scsigmax:get(e-1) or 0) - (scsigmax:get(e-2) or 0)) * ((scsigmax:get(e) or 0) - (scsigmax:get(e-1) or 0)) < 0 then
  scp:line_to(e*2+17,y)
  end
  end

  for e = i-1, i-validwave, -1 do
  local y = (scsigmin:get(e-1) or 0)*172+172+15
  scp:line_to(e*2+16,y)
  if e > i-validwave and ((scsigmin:get(e-1) or 0) - (scsigmin:get(e-2) or 0)) * ((scsigmin:get(e) or 0) - (scsigmin:get(e-1) or 0)) < 0 then
  scp:line_to(e*2+15,y)
  end
  end

  g:set_color(122,122,140,1)
  g:fill_path(scp)
  validwave = 0

  end

  end  

end