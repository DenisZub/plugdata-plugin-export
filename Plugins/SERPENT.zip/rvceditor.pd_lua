local vce = pd.Class:new():register("rvceditor")

function vce:initialize()
  self:set_size(808, 376)
  self.inlets  = 8
  self.outlets = 1   
  self.points = {0.01, 0, 0.33, 0.5, 0.5, 0.66, 0.99, 1, 0.5}
  self.varray = {}
  for i = 1, 256 do self.varray[i] = 0 end
  self.selpoints = {}
  self.selsegments = {}
  self.seg = 0
  self.hlg = 0
  self.ishover = false
  self.gx = 0
  self.gy = 0
  self.tx = 0
  self.ty = 0
  self.tz = 0
  self.tzo = 0
  self.shift = 1
  self.ctrl = 0
  self.priority = 1
  self.showrmc = 0
  self.volenvvis = 1
  return true
end

local min, max= math.min, math.max

local function clip(x, lo, hi)
return min(hi, max(lo, x))
end



function vce:postinitialize()
  self:repaint(2)
end



function vce:in_1_list(l)
local list = l
self.points = list
self:outlet(1, "list", self.points)
end

function vce:in_2_float(s)
  if s == 1 then
  self.shift = 0.25
  else 
  self.shift = 1 
  end
  self:anchor()
end

function vce:in_3_float(pr)
self.priority = pr
end

function vce:in_4_float(rmv)
self.showrmc = rmv
  self:repaint(2)
end

function vce:in_5()
  self:repaint(1)
  self:repaint(2)
end

function vce:in_6()
  self:repaint(2)
end

function vce:in_7_float(vev)
self.volenvvis = vev
end

function vce:in_8_float(c)
self.ctrl = c
end

function vce:anchor()
  if self.hlg > 0 then
  self.tx = self.points[(self.hlg-1)*3+1]*776/self.shift-self.gx
  self.ty = 344-(self.points[(self.hlg-1)*3+2]*344)/self.shift-self.gy
  end
  if self.seg > 0 then
  self.tz = 400-(self.points[(self.seg-1)*3+3]*400)/self.shift-self.gy
  self.tzo = (self.points[(((3-self.seg)-1))*3+3]*400)/self.shift-self.gy
  end
end

function vce:mouse_move(x,y)
self.gx = x
self.gy = y
self.hlg = 0

for i = 1, 3 do
if x-11 < (self.points[(i-1)*3+1]*776+16) and x+11 > (self.points[(i-1)*3+1]*776+16) and 376-y-11 < (self.points[(i-1)*3+2]*344+16) and 376-y+11 > (self.points[(i-1)*3+2]*344+16)then
self.selpoints[i] = 1
self.hlg = i
self.seg = 0
else 
self.selpoints[i] = 0
end
end

for i = 1, 2 do
if x+12 < (self.points[(i-1)*3+4]*776+16) and x-12 > (self.points[(i-1)*3+1]*776+16) then
self.selsegments[i] = 1
self.seg = i
self.hlg = 0
else 
self.selsegments[i] = 0
end 
end

if self.hlg > 0 and self.ishover == false then
  self:repaint(2)
  self.ishover = true
  end
  if self.hlg == 0 and self.ishover == true then
  self:repaint(2)
  self.ishover = false
end
end

function vce:mouse_down(x,y)
self.gx = x
self.gy = y
self:anchor()
end

function vce:mouse_drag(x,y)
self.gx = x
self.gy = y

   if self.volenvvis > 0 then

  for i = 1, 3 do
    if self.selpoints[i] == 1 then
    self.points[(i-1)*3+1] = clip(clip((self.gx+self.tx)*self.shift,0,776)/776,(self.points[(i-2)*3+1] or -0.01) + 0.01, (self.points[(i)*3+1] or 1.01) - 0.01)
    self.hlg = i
    if i==2 then
    self.points[5] = clip((344-self.gy-self.ty)*self.shift,0,344)/344
    if self.points[5] == 0 or self.points[5] == 1 then
    self:anchor()
    end
    end
    if self.points[(i-1)*3+1] == (self.points[(i-2)*3+1] or -0.01) + 0.01 or self.points[(i-1)*3+1] == (self.points[(i)*3+1] or 1.01) - 0.01 then
    self:anchor()
    end
    end
  end

  for i = 1, 2 do
    if self.selsegments[i] == 1 then
    if self.ctrl == 1 then
    local ii = 3-i
    self.points[i*3] = clip((400-self.gy-self.tz)*self.shift,0,400)/400
    self.points[ii*3] = clip((self.tzo+self.gy)*self.shift,0,400)/400 
    else
    self.points[i*3] = clip((400-self.gy-self.tz)*self.shift,0,400)/400
    if self.points[i*3] == 0 or self.points[i*3] == 1 then
    self:anchor()
    end
    end
    end
  end
  self:outputlist()
  end
end

function vce:mouse_up(x,y)
  
  self.gx = x
  self.gy = y
  self:anchor()
  self.hlg = 0

  for i = 1, 3 do
  if x-11 < (self.points[(i-1)*3+1]*776+16) and x+11 > (self.points[(i-1)*3+1]*776+16) and 376-y-11 < (self.points[(i-1)*3+2]*344+16) and 376-y+11 > (self.points[(i-1)*3+2]*344+16)then
  self.selpoints[i] = 1
  self.hlg = i
  self.seg = 0
  else 
  self.selpoints[i] = 0
  end
  end

  for i = 1, 2 do
  if x+12 < (self.points[(i-1)*3+4]*776+16) and x-12 > (self.points[(i-1)*3+1]*776+16) then
  self.selsegments[i] = 1
  self.seg = i
  self.hlg = 0
  else 
  self.selsegments[i] = 0
  end 
  end

  self:outputlist()
  self:repaint(2)

end

function vce:outputlist()
  self:outlet(1, "list", self.points)
end

function vce:paint(g)

    local pdlvmax = pd.Table:new():sync("pdlarrayvismax")
    local pdlvmin = pd.Table:new():sync("pdlarrayvismin")
    
    local op = Path(16,(pdlvmin:get(0) or 0)*172+172+16)

    for i = 1, 388 do
    local y = (pdlvmax:get(i-1) or 0)*172+172+17
    op:line_to(i*2+16,y)
    if ((pdlvmax:get(i-1) or 0) - (pdlvmax:get(i-2) or 0)) * ((pdlvmax:get(i) or 0) - (pdlvmax:get(i-1) or 0)) < 0 then
    op:line_to(i*2+17,y)
    end
    end

    for i = 388, 1, -1 do
    local y = (pdlvmin:get(i-1) or 0)*172+172+15
    op:line_to(i*2+16,y)
    if ((pdlvmin:get(i-1) or 0) - (pdlvmin:get(i-2) or 0)) * ((pdlvmin:get(i) or 0) - (pdlvmin:get(i-1) or 0)) < 0 then
    op:line_to(i*2+15,y)  
    end
    end

    if self.priority == 0 then
    if self.volenvvis > 0 then 

    local pdlar = pd.Table:new():sync("pdlarray")

    local p = Path(16,(1-(pdlar:get(0) or 0))*344+16)

    for i = 1, 256 do
    p:line_to((i/256)*776+16,(1-(pdlar:get(i-1) or 0))*344+16)
    end

    g:set_color(12,64,38,1)
    g:stroke_path(p,4)
    g:set_color(34,238,139,1)
    g:fill_path(op)
    else
    g:set_color(34,238,139,1)
    g:fill_path(op)
    end
    
    else
      
    if self.volenvvis > 0 then
    g:set_color(12,64,38,1)
    g:fill_path(op)
    else
    g:set_color(34,238,139,1)
    g:fill_path(op)
    end

  end

end

function vce:paint_layer_2(g)

  if self.volenvvis > 0 and self.priority == 1 then
    local pdlar = pd.Table:new():sync("pdlarray")
    local p = Path(16,(1-(pdlar:get(0) or 0))*344+16)

    for i = 1, 256 do
    p:line_to((i/256)*776+16,(1-(pdlar:get(i-1) or 0))*344+16)
    end
    
    g:set_color(4,5,4,1)
    g:stroke_path(p,9)
    g:set_color(34,238,139,1)
    g:stroke_path(p,4)

    for i = 1, 3 do
    g:set_color(4,5,4,0.5)
    g:fill_ellipse(self.points[(i-1)*3+1]*776, 344-self.points[(i-1)*3+2]*344, 32, 32)
    g:set_color(34,238,139,1)
    g:fill_ellipse(self.points[(i-1)*3+1]*776+4, 344-self.points[(i-1)*3+2]*344+4, 24, 24)
    g:set_color(4,5,4,0.5)
    g:fill_ellipse(self.points[(i-1)*3+1]*776+9.5, 344-self.points[(i-1)*3+2]*344+9.5, 13, 13)
    end
    if self.hlg > 0 then
    g:set_color(34,238,139,1)
    g:fill_ellipse(self.points[(self.hlg-1)*3+1]*776+13, 344-self.points[(self.hlg-1)*3+2]*344+13, 6, 6)
    end
  end

  if self.showrmc == 1 then
    local rmcv = pd.Table:new():sync("rmenvvis") 
    local rcp = Path(16,360)
    for i = 1, 256 do
    rcp:line_to(i*3.03125+16,(1-(rmcv:get(i-1) or 0))*344+16)
    end  
    g:set_color(34,238,139,0.5)
    g:stroke_path(rcp,4)
  end
end