local wvfv = pd.Class:new():register("rwvv3")

function wvfv:initialize()
  self:set_size(320, 140)
  self.inlets  = 1
  return true
end


function wvfv:postinitialize()
  self:repaint()
end

function wvfv:in_1()
self:repaint()
end

function wvfv:paint(g)

local trsc = pd.Table:new():sync("transientar")  
local trsp = Path(16,146)
for i = 1, 288 do
  trsp:line_to(i+16,math.min(trsc:get(i-1) or 1)*142)
end
  trsp:line_to(304,146)
  trsp:line_to(16,146)
  g:set_color(212,212,220,0.75)
  g:fill_path(trsp)
end