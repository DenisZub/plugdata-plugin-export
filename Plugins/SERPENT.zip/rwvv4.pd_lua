local wvft = pd.Class:new():register("rwvv4")

function wvft:initialize()
  self:set_size(320, 142)
  self.inlets  = 1
  return true
end


function wvft:postinitialize()
  self:repaint()
end

function wvft:in_1()
self:repaint()
end

function wvft:paint(g)

local tmaxr = pd.Table:new():sync("maxts")  
local tminr = pd.Table:new():sync("mints")  
local lac = pd.Table:new():sync("lacurve")  
local msve = pd.Table:new():sync("msvolenv")  

local tp = Path(8,(tmaxr:get(0) or 0)*63+71)

for i = 1, 152 do
  local y = (tmaxr:get(i-1) or 0)*63+72
  tp:line_to(i*2+8,y)
  if ((tmaxr:get(i-1) or 0) - (tmaxr:get(i-2) or 0)) * ((tmaxr:get(i) or 0) - (tmaxr:get(i-1) or 0)) < 0 then
  tp:line_to(i*2+9,y)
  end
end

for i = 152, 1, -1 do
  local y = (tminr:get(i-1) or 0)*63+70
  tp:line_to(i*2+8,y)
  if ((tminr:get(i-1) or 0) - (tminr:get(i-2) or 0)) * ((tminr:get(i) or 0) - (tminr:get(i-1) or 0)) < 0 then
  tp:line_to(i*2+7,y)
  end
end

  g:set_color(17,116,68,1)
  g:fill_path(tp)

local msvep = Path(160,(1-(msve:get(0) or 0))*126+8)

for i = 1, 76 do
  msvep:line_to(i*2+160,(1-(msve:get((i-1)) or 0))*126+8)
end

  g:set_color(34,238,139,1)
  g:stroke_path(msvep,4)


local lap = Path(8,(1-(lac:get(0) or 0))*126+8)

for i = 1, 76 do
  lap:line_to(i*2+8,(1-(lac:get((i-1)*6.315) or 0))*126+8)
end

  g:set_color(212,212,220,1)
  g:stroke_path(lap,4)

end