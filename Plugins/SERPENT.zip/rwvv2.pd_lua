local wvsv = pd.Class:new():register("rwvv2")

function wvsv:initialize()
  self:set_size(332, 128)
  self.inlets  = 2
  return true
end


function wvsv:postinitialize()
  self:repaint()
end

function wvsv:in_1()
self:repaint(1)
end

function wvsv:in_2()
self:repaint(2)
end

function wvsv:paint(g)

local rtsenv = pd.Table:new():sync("fftls")  
local rtsp = Path(0,(rtsenv:get(0) or 0)*64+64)

local ftsc = pd.Table:new():sync("fftspectrum")  
local fsp = Path(0,119)


for i = 1, 166 do

  rtsp:line_to(i*2,(rtsenv:get(i-1) or 0)*64+64)

  fsp:line_to(i*2,(ftsc:get(i-1) or 0)*64+64)

end

  fsp:line_to(332,119)
  fsp:line_to(0,119)

  rtsp:line_to(332,11)
  rtsp:line_to(0,11)


  g:set_color(37,37,47,1)
  g:fill_path(fsp)
  g:set_color(122,122,140,0.75)
  g:fill_path(rtsp,2)


end




function wvsv:paint_layer_2(g)

  local sesig = pd.Table:new():sync("lsgraphedit")  
  local sep = 0
  local pstart = 0
  local samplex = 0
  local sampley = 0

  for i = 1, 166 do

    if (sesig:get(i) or 1) < 0.799 then
    if pstart == 0 then
    sep = Path((i-1)*2,(sesig:get((i-1)) or 0)*64+64)
    samplex = (i-1)*2
    sampley = (sesig:get((i-1)) or 0)*64+64
    pstart = 1
    end
    sep:line_to(i*2,(sesig:get(math.min(i,166)) or 0)*64+64)
    end

  end




  g:set_color(122,122,140,0.75)
  g:draw_line(0,117.5,332,117.5,3)

  g:set_color(4,5,4,1)
  g:stroke_path(sep,9)
  g:fill_ellipse(samplex-4.5,sampley-4.5,9,9)

  g:set_color(212,212,220,1)
  g:stroke_path(sep,4)
  g:fill_ellipse(samplex-2,sampley-2,4,4)

  end