local wvis = pd.Class:new():register("2windowvis")

function wvis:initialize(sel, atoms)
  self.inlets = 1
  self.outlets = 1
  self.arm = 0
  self:set_size(18, 18)
  return true
end

function wvis:paint(g)
  if self.arm == 1 then
    self:outlet(1,"bang",{})
    self.arm = 0
  end

end

function wvis:in_1()
  self.arm = 1
end