local wvfvs = pd.Class:new():register("rwvv6")

function wvfvs:initialize()
  self:set_size(320, 142)
  self.inlets  = 2
  return true
end


function wvfvs:postinitialize()
  self:repaint()
end

function wvfvs:in_1()
self:repaint(1)
end

function wvfvs:in_2()
self:repaint(2)
end

function wvfvs:paint(g)

local ftsc = pd.Table:new():sync("NSG")  
local ffsp = Path(0,148)
for i = 1, 160 do
  ffsp:line_to(i*2,math.min(ftsc:get(i-1) or 1)*144)
end
  ffsp:line_to(320,162)
  ffsp:line_to(0,162)
  g:set_color(26,179,104,0.65)
  g:fill_path(ffsp)
end
function wvfvs:paint_layer_2(g)

local bpbp = pd.Table:new():sync("bp")  
local pbp = Path(0,math.min(bpbp:get(0) or 0)*144)

for i = 1, 160 do
  pbp:line_to(i*2,math.min(bpbp:get(i-1) or 0)*144)
end

  g:set_color(212,212,220,1)
  g:stroke_path(pbp,4)
end