local suce = pd.Class:new():register("rsuceditor")

function suce:initialize()
  self:set_size(452, 260)
  self.inlets  = 4
  self.outlets = 1   
  self.points = {0.01, 0, 0.33, 0.5, 0.5, 0.66, 0.99, 1, 0.5}
  self.varray = {}
  for i = 1, 256 do self.varray[i] = 0 end
  self.selpoints = {}
  self.selsegments = {}
  self.seg = 0
  self.hlg = 0
  self.ishover = false
  self.gx = 0
  self.gy = 0
  self.tx = 0
  self.ty = 0
  self.tz = 0
  self.tzo = 0
  self.shift = 1
  self.ctrl = 0
  return true
end

local floor, min, max, abs = math.floor, math.min, math.max, math.abs

local function clip(x, lo, hi)
return min(hi, max(lo, x))
end

function suce:postinitialize()
  self:repaint()
end



function suce:in_1_list(l)
local list = l
self.points = list
self:outlet(1, "list", self.points)
end

function suce:in_2_float(s)
  if s == 1 then
  self.shift = 0.25
  else 
  self.shift = 1 
  end
  self:anchor()
end

function suce:in_3()
  self:repaint()
end

function suce:in_4_float(c)
self.ctrl = c
end

function suce:anchor()
  if self.hlg > 0 then
  self.tx = self.points[(self.hlg-1)*3+1]*420/self.shift-self.gx
  self.ty = 228-(self.points[(self.hlg-1)*3+2]*228)/self.shift-self.gy
  end
  if self.seg > 0 then
  self.tz = 400-(self.points[(self.seg-1)*3+3]*400)/self.shift-self.gy
  self.tzo = (self.points[(((3-self.seg)-1))*3+3]*400)/self.shift-self.gy
  end
end

function suce:mouse_move(x,y)
self.gx = x
self.gy = y
self.hlg = 0

for i = 1, 3 do
if x-11 < (self.points[(i-1)*3+1]*420+16) and x+11 > (self.points[(i-1)*3+1]*420+16) and 260-y-11 < (self.points[(i-1)*3+2]*228+16) and 260-y+11 > (self.points[(i-1)*3+2]*228+16)then
self.selpoints[i] = 1
self.hlg = i
self.seg = 0
else 
self.selpoints[i] = 0
end
end

for i = 1, 2 do
if x+12 < (self.points[(i-1)*3+4]*420+16) and x-12 > (self.points[(i-1)*3+1]*420+16) then
self.selsegments[i] = 1
self.seg = i
self.hlg = 0
else 
self.selsegments[i] = 0
end 
end

if self.hlg > 0 and self.ishover == false then
  self:repaint()
  self.ishover = true
  end
  if self.hlg == 0 and self.ishover == true then
  self:repaint()
  self.ishover = false
end

end

function suce:mouse_down(x,y)
self.gx = x
self.gy = y
self:anchor()
end

function suce:mouse_drag(x,y)
self.gx = x
self.gy = y

  for i = 1, 3 do
    if self.selpoints[i] == 1 then
    self.points[(i-1)*3+1] = clip(clip((self.gx+self.tx)*self.shift,0,420)/420,(self.points[(i-2)*3+1] or -0.01) + 0.01, (self.points[(i)*3+1] or 1.01) - 0.01)
    self.hlg = i
    if i==2 then
    self.points[5] = clip((228-self.gy-self.ty)*self.shift,0,228)/228
    if self.points[5] == 0 or self.points[5] == 1 then
    self:anchor()
    end
    end
    if self.points[(i-1)*3+1] == (self.points[(i-2)*3+1] or -0.01) + 0.01 or self.points[(i-1)*3+1] == (self.points[(i)*3+1] or 1.01) - 0.01 then
    self:anchor()
    end
    end
  end

    for i = 1, 2 do
    if self.selsegments[i] == 1 then
    if self.ctrl == 1 then
    local ii = 3-i
    self.points[i*3] = clip((400-self.gy-self.tz)*self.shift,0,400)/400
    self.points[ii*3] = clip((self.tzo+self.gy)*self.shift,0,400)/400 
    else  
    self.points[i*3] = clip((400-self.gy-self.tz)*self.shift,0,400)/400
    if self.points[i*3] == 0 or self.points[i*3] == 1 then
    self:anchor()
    end
    end
    end
    end

  self:outputlist()

end

function suce:mouse_up(x,y)

  self.gx = x
  self.gy = y
  self:anchor()
  self.hlg = 0

  for i = 1, 3 do
  if x-11 < (self.points[(i-1)*3+1]*420+16) and x+11 > (self.points[(i-1)*3+1]*420+16) and 260-y-11 < (self.points[(i-1)*3+2]*228+16) and 260-y+11 > (self.points[(i-1)*3+2]*228+16)then
  self.selpoints[i] = 1
  self.hlg = i
  self.seg = 0
  else 
  self.selpoints[i] = 0
  end
  end

  for i = 1, 2 do
  if x+12 < (self.points[(i-1)*3+4]*420+16) and x-12 > (self.points[(i-1)*3+1]*420+16) then
  self.selsegments[i] = 1
  self.seg = i
  self.hlg = 0
  else 
  self.selsegments[i] = 0
  end 
  end

  self:outputlist()
  
end

function suce:outputlist()
  self:outlet(1, "list", self.points)
end

function suce:paint(g)

local pdlar2 = pd.Table:new():sync("pdlarray2") 
local p = Path(16,(1-(pdlar2:get(0) or 0))*228+16)

for i = 1, 256 do

  p:line_to((i/256)*420+16,(1-(pdlar2:get(i-1) or 0))*228+16)

  end

  g:set_color(4,5,4,1)
  g:stroke_path(p,12)
  g:set_color(212,212,220,1)
  g:stroke_path(p,4)

  for i = 1, 3 do
  g:set_color(4,5,4,0.5)
  g:fill_ellipse(self.points[(i-1)*3+1]*420, 228-self.points[(i-1)*3+2]*228, 32, 32)
  g:set_color(212,212,220,1)
  g:fill_ellipse(self.points[(i-1)*3+1]*420+4, 228-self.points[(i-1)*3+2]*228+4, 24, 24)
  g:set_color(4,5,4,0.5)
  g:fill_ellipse(self.points[(i-1)*3+1]*420+9.5, 228-self.points[(i-1)*3+2]*228+9.5, 13, 13)
  end

  if self.hlg > 0 then
  g:set_color(212,212,220,1)
  g:fill_ellipse(self.points[(self.hlg-1)*3+1]*420+13, 228-self.points[(self.hlg-1)*3+2]*228+13, 6, 6)
  end

end