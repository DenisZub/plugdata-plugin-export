local closebang = pd.Class:new():register("closebang")

function closebang:initialize(sel, atoms)
   return true
end

function closebang:finalize()
   pd.send("__closebang", "bang", {})
end
